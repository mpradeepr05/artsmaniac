<?xml version="1.0" encoding="UTF-8"?><rsd version="1.0" xmlns="http://archipelago.phrasewise.com/rsd">
  <service>
    <engineName>WordPress</engineName>
    <engineLink>http://wordpress.org/</engineLink>
    <homePageLink>http://apasmart.pl</homePageLink>
    <apis>
      <api name="WordPress" blogID="1" preferred="true" apiLink="http://apasmart.pl/xmlrpc.php" />
      <api name="Movable Type" blogID="1" preferred="false" apiLink="http://apasmart.pl/xmlrpc.php" />
      <api name="MetaWeblog" blogID="1" preferred="false" apiLink="http://apasmart.pl/xmlrpc.php" />
      <api name="Blogger" blogID="1" preferred="false" apiLink="http://apasmart.pl/xmlrpc.php" />
          </apis>
  </service>
</rsd>
