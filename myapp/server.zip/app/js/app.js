function myCtrl($scope, $http) {
  //console.log("i am");

$http.get('/records').success(function(response){
  $scope.records = response;
});

}