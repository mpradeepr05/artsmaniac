var express = require('express');
var app = express();
var mongojs = require('mongojs');
var db = mongojs('records', ['records']);

app.use(express.static(__dirname + "/app"));

app.get('/records', function (req, res) {
	//console.log("i recevied")
db.records.find(function (err, docs){
	console.log(docs);
	//res.json(docs);
});

});

app.listen(3000);
console.log("server running 3000");